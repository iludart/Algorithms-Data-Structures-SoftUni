﻿namespace _03_DS_StacksAndQueues_Homework
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
