﻿namespace P07.LinkedQueue
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
