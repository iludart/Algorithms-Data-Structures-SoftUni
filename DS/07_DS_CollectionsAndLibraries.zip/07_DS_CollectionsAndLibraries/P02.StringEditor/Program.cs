﻿namespace P02.StringEditor
{
    using System;

    public class Program
    {
        private static void Main()
        {
            var stringEditor = new StringEditor();
            stringEditor.Run();
        }
    }
}
