﻿namespace DirTree
{
    public class DirTree
    {
        public DirTree()
        {
            
        }
    }
}
