﻿namespace P03.CalculateArithmeticExpression
{
    public enum TokenType
    {
        Number,
        Operator,
        LeftBracket,
        RightBracket
    }
}
