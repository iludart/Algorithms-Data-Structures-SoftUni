namespace P01.FindTheRoot
{
    public class Node
    {
        public int Value { get; set; }

        public bool HasParent { get; set; }
    }
}